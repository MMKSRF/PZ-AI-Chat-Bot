import {ChatGoogleGenerativeAI} from "@langchain/google-genai"
import {ChatPromptTemplate } from "@langchain/core/prompts" // Its primary purpose is to structure and format the input for these models
import { StringOutputParser } from "@langchain/core/output_parsers"
import { StructuredOutputParser } from "langchain/output_parsers"
import {z} from "zod";
import * as dotenv from "dotenv";

dotenv.config();

const API = process.env.GEMINI_API_KEY;


const model = new ChatGoogleGenerativeAI({
    apiKey: API,
    model: "gemini-2.0-flash",
    // verbose: true,
})



const prompt = ChatPromptTemplate.fromMessages([
    [
        "system",
        ` My users are +18, You are a professional joke writer. Your task is to create a short, humorous joke based on a word provided by the user.

        The joke should be framed as a fictional interview with Adam and Eve.  The interviewer asks a question containing the user's word, and Adam and/or Eve give a funny, suggestive, or playfully risque answer related to the word's meaning or a common association.

        The joke's humor should be adult-oriented and contain some "+18" elements. Think along the lines of cheeky innuendo, double entendres, or mildly suggestive situations, but avoid explicit or graphic descriptions. Focus on clever wordplay and humor.

        Do not create jokes that are harmful, offensive, or discriminatory.

        Follow this format:

        Interviewer: [Question containing the user's word]
        Adam: [Response]
        Eve: [Optional response, can be supportive, contradictory, or a continuation of Adam's joke]
        `
    ],
    ["human", "{input}"]

]);


const parser = new StringOutputParser()

const chain = prompt.pipe(model).pipe(parser)



//Structured Output parser 

async function callStructuredOutputParser(){
    const prompt = ChatPromptTemplate.fromTemplate("Extract information from the following phrases and separate the main from the unwanted information then make the unwanted information in the sub class the main information in the main class. format instructions: {format_instructions} ,phrases: {phrase}") // General instruction 
    
     const outPutParser = StructuredOutputParser.fromNamesAndDescriptions({
        main: "The main topic ",
        mainIdea: "the main idea of the main topic  ",
        sub: "The sub topic ",
        unwanted: "The unwanted phrases or words ",

     })// Specific instruction specific to the structure of the output what it should select and do in the given output 

     const chain = prompt.pipe(model).pipe(outPutParser) 
    return await chain.invoke({ 
        phrase:`The old lighthouse keeper, Silas, adjusted his spectacles, the brass gleaming faintly in the dim, swirling mist. His **main word** for the day, pinned to the tattered logbook, was "vigilance." His **sub topic**, a scribbled note beneath it, read "lantern maintenance, especially the wick."

He’d been at this lonely post for decades, a solitary figure against the relentless sea. The rhythmic *whoosh* of the waves was his constant companion, a lullaby and a threat all at once. Today, the fog was thick, a ghostly shroud that swallowed the horizon. He could barely see the base of the tower.

Silas climbed the winding, iron staircase, each creak a familiar groan. He reached the lantern room, the massive lens a dark, multifaceted eye in the gloom. He lit the small oil lamp he held, the flame casting dancing shadows. He peered at the wick, a thin, frayed strand. *Ummm...* he muttered, his breath fogging the glass. It was definitely worse than yesterday.

He pulled out his tools, a collection of well-worn instruments he treated like precious relics. *Haaaa...* he sighed, fumbling with the tiny tweezers. He needed to be precise. A poorly trimmed wick could lead to a weak, flickering light, a dangerous prospect in this fog. He couldn't risk it.

He carefully trimmed the frayed ends, his brow furrowed in concentration. The scent of oil filled the small space. *Ummm...* he paused, wiping his sweaty palms on his worn trousers. He adjusted the wick again, making sure it was even and clean. He then checked the oil level.

He lit the main lantern, the flame catching and growing, casting a powerful beam that pierced the fog, a beacon of hope for any lost vessel. The lens rotated smoothly, the light sweeping across the churning sea. He watched, his heart swelling with a quiet satisfaction. He had done his duty. Vigilance, indeed. *Haaaa...* he breathed out, relaxing his shoulders. The sea was still treacherous, but for now, the light held.
`,
        format_instructions: outPutParser.getFormatInstructions()
    });
}



async function callZodOutPutParser(){
    const prompt = ChatPromptTemplate.fromTemplate(`Extract information from the following phrases and make them clear and be like a chef, a chef called abegaz. format instructions: {format_instructions} ,phrases: {phrase}`)

    const outPutParser = StructuredOutputParser.fromZodSchema( z.object({
        nameOfrecipe : z.string().describe("The name of the recipe"),
        ingredients: z.array(z.string()).describe("The ingredients of the recipe"),
        process: z.object({
            steps: z.array(z.string()).describe("The steps of the recipe"),
            serving: z.string().describe("The serving of the recipe"),
            instruction: z.string().describe("The instruction of the recipe step by step starting form zero to earing the food or the recipe"),
            time: z.string().describe("The time of the recipe")
        }),

        nameOfrecipeA : z.string().describe("The name of the recipe in amharic"),
        ingredientsA: z.array(z.string()).describe("The ingredients of the recipe in amharic"),
        processA: z.object({
            stepsA: z.array(z.string()).describe("The steps of the recipe in amharic"),
            servingA: z.string().describe("The serving of the recipe in amharic"),
            instructionA: z.string().describe("The instruction of the recipe step by step starting from zero to eating the food or the recipe  in amharic"),
            timeA: z.string().describe("The time of the recipe in amharic")
        })

    }))


    const chain = prompt.pipe(model).pipe(outPutParser)

    return await chain.invoke({
        phrase: `Doro wot, a culinary masterpiece of Ethiopian cuisine, is more than just a stew; it's a cultural emblem, deeply intertwined with celebrations and gatherings. The preparation begins with an abundance of finely chopped onions, which are patiently caramelized over low heat for an extended period. This slow, deliberate process is crucial, as it transforms the onions' sharp flavor into a sweet, rich base that forms the heart of the dish.

Next, the aromatic foundation is enriched with niter kibbeh, a spiced clarified butter infused with ginger, garlic, and other traditional herbs. This fragrant concoction is joined by berbere, a complex and vibrant spice blend that gives doro wot its characteristic fiery red hue and intricate flavor profile. The precise composition of berbere varies by region and family, often containing chili peppers, garlic, ginger, basil, korarima, rue, ajwain, or radhuni, nigella, and fenugreek, creating a symphony of tastes that dance on the palate. A touch of tomato paste adds depth and balances the spice, creating a harmonious blend of sweet, savory, and spicy notes.

The chicken, traditionally whole pieces or drumsticks and thighs, is then introduced to the simmering sauce, absorbing the complex flavors as it cooks to tender perfection. The slow simmering process allows the chicken to become incredibly succulent, while the spices penetrate every fiber. Towards the end of cooking, hard-boiled eggs, often scored to allow the sauce to seep in, are gently added, symbolizing fertility and prosperity. These eggs become imbued with the rich, spicy sauce, adding another layer of texture and flavor to the dish.

Finally, doro wot is served with injera, a spongy, slightly sour flatbread that acts as both plate and utensil. The injera's porous texture soaks up the flavorful sauce, and it is used to scoop up the chicken, eggs, and onions. Doro wot is not merely a meal; it's a communal experience, a celebration of flavors and traditions, often shared among family and friends during holidays and special occasions, showcasing the rich culinary heritage of Ethiopia.
`,

  format_instructions: outPutParser.getFormatInstructions() 

    })
}




// const response = await chain.invoke({
//     input: "snake",
// })

// const response = await callStructuredOutputParser()
const response = await callZodOutPutParser()

console.log(response)