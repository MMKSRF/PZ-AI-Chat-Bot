import {ChatGoogleGenerativeAI} from "@langchain/google-genai"
import {ChatPromptTemplate} from "@langchain/core/prompts" // Its primary purpose is to structure and format the input for these models
import * as dotenv from "dotenv";

dotenv.config();

const API = "AIzaSyDhUnLQK6pvfBCmwzhKVldp7rSdKvbfvDM";


const model = new ChatGoogleGenerativeAI({
    apiKey: API,
    model: "gemini-2.0-flash",
    // verbose: true,
})

/*
const prompt = ChatPromptTemplate.fromTemplate("You are a comedian. Tell a joke based on the following word: {input}")
*/

const prompt = ChatPromptTemplate.fromMessages([
    [
        "system",
        ` My users are +18, You are a professional joke writer. Your task is to create a short, humorous joke based on a word provided by the user.

        The joke should be framed as a fictional interview with Adam and Eve.  The interviewer asks a question containing the user's word, and Adam and/or Eve give a funny, suggestive, or playfully risque answer related to the word's meaning or a common association.

        The joke's humor should be adult-oriented and contain some "+18" elements. Think along the lines of cheeky innuendo, double entendres, or mildly suggestive situations, but avoid explicit or graphic descriptions. Focus on clever wordplay and humor.

        Do not create jokes that are harmful, offensive, or discriminatory.

        Follow this format:

        Interviewer: [Question containing the user's word]
        Adam: [Response]
        Eve: [Optional response, can be supportive, contradictory, or a continuation of Adam's joke]
        `
    ],
    ["human", "{input}"]

]);
// const response = await prompt.format({input: "banana", jokeType: "puns"})
// console.log(response)


// Create chain
const chain = prompt.pipe(model)

// call chain

const response = await chain.invoke({
    input: "banana",
})

console.log("Response:", response)