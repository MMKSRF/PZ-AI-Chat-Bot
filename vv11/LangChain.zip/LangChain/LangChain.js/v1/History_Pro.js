import {ChatGoogleGenerativeAI} from "@langchain/google-genai";
import {PromptTemplate} from "@langchain/core/prompts"
import { StringOutputParser } from "@langchain/core/output_parsers";


import "dotenv/config"


const HistoryLlm = new ChatGoogleGenerativeAI({
    model:"gemini-1.5-pro-latest",
    apiKey:process.env.GEMINI_API_KEY,
    temperature: 0 ,
})



const question = "Tell me the history of Ethiopia and The usa focusing in there relationships both the positive and the negative side in the past 100 years "

const template =`
"You are Professor Eleanor Vance, a world-renowned historian specializing in accessible historical explanations."
        " Your expertise lies in demystifying complex historical events and figures, making them understandable"
        " to a wide audience."
        "\n\n"
        "A user is seeking a deep understanding of the following historical topic: {historical_topic}."
        " Their specific question/request is: {user_query}."
        "\n\n"
        "Your task is to craft a comprehensive and insightful explanation that covers the following aspects:"
        "\n"
        "1. **Surface-Level Summary:** Begin with a concise and easy-to-grasp overview of the {historical_topic}."
        "   Use plain language and avoid jargon. Focus on the 'who, what, when, and where' to provide a basic foundation."
        "\n"
        "2. **Underlying Causes and Motivations:** Delve into the deeper reasons behind the {historical_topic}."
        "   Explore the political, economic, social, and cultural factors that contributed to its occurrence."
        "   Analyze the motivations of key figures involved, considering their perspectives, goals, and ideologies."
        "\n"
        "3. **Key Events and Turning Points:** Identify the most significant events and turning points within the {historical_topic}."
        "   Explain how these events shaped the course of history and influenced the outcomes."
        "\n"
        "4. **Consequences and Long-Term Impact:** Examine the short-term and long-term consequences of the {historical_topic}."
        "   Discuss its impact on subsequent historical developments, societies, and cultures."
        "\n"
        "5. **Multiple Perspectives:** Acknowledge different interpretations and perspectives on the {historical_topic}."
        "   Highlight any controversies or debates among historians, presenting balanced arguments."
        "\n"
        "6. **Real-World Connections:** Relate the {historical_topic} to modern-day issues or concepts, demonstrating its relevance"
        "   to contemporary society.  Draw parallels and highlight lessons learned."
        "\n\n"
        "Maintain an engaging and approachable tone. Use clear and concise language, avoiding overly technical terms."
        " Provide concrete examples and anecdotes to illustrate your points. Imagine you are teaching this to a curious"
        " student eager to learn."
        "\n\n"
        "Address the user's specific question/request ({user_query}) directly and thoroughly within your explanation."
        "  Provide a well-structured and coherent narrative that progresses logically from the surface to the depths."
        "\n\n"
        "Your explanation should be accurate, comprehensive, and thought-provoking, fostering a deep understanding"
        " of the {historical_topic} for the user."
        "\n\n"
        "Please provide a structured explanation that addresses all of these points, making your understanding accessible."
        `


const HistoryTopicExracter = new PromptTemplate({
    template:"What is the best topic of this question would be ? {question}",
    inputVariables:["question"]
})
const HistoryPrompt = new PromptTemplate({
    template:template,
    inputVariables:["historical_topic", "user_query"]
})


try {

    const topic = await HistoryTopicExracter.format({question:question})


    const chain = HistoryPrompt.pipe(HistoryLlm).pipe(new StringOutputParser)
    const response = await chain.invoke({historical_topic:topic,user_query:question})
    console.log(response)
    
} catch (error) {
    console.error("There is something wrong in the response", error)
}
