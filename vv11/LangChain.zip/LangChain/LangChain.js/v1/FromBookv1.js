import { ChatGoogleGenerativeAI} from "@langchain/google-genai"
import {PromptTemplate} from "@langchain/core/prompts"
import { StringOutputParser, StructuredOutputParser } from "@langchain/core/output_parsers";


import prompts from 'prompts';
import 'dotenv/config'


// all of things that we are going to have communication  with the llm is pass by this Object name called "llm"
const llm = new ChatGoogleGenerativeAI ({
    model: "gemini-1.5-pro-latest",
    apiKey: process.env.GEMINI_API_KEY,
    debug: true
})



const prompt = new PromptTemplate({
    inputVariables:["country", "Emotion"],
    template:`You are a currency expert.
You give information about a specific currency used in a specific country.
Avoid giving information about fictional places.
If the country is fictional or non-existent, answer: I don't know.
Answer the question: What is the currency of {country}?
 , Make the emotion based on this types of emotion: {Emotion}`
})



const chain = prompt.pipe(llm)

// title from the topic 

const titlePrompt = new PromptTemplate({
    inputVariables: ["topic"],
    template: `as a profectional esay righter give me a tittle based on this topic:{topic} `
})

const essayPrompt = new PromptTemplate({
    inputVariables: ["tittle" , "Emotion","format_instruction"],
    template: "Your name is Perez Endale and you are a profectinal essay righter and so generate for me an essay more than 3 paragraph based on this tittle : {tittle}  , Make the emotion based on this types of emotion: {Emotion}, {format_instruction}",
    
})

const titleChain = titlePrompt.pipe(llm).pipe(new StringOutputParser())
const essayChain = essayPrompt.pipe(llm)

const structuredParser =  StructuredOutputParser.fromNamesAndDescriptions({
    tittle:" The Name name of the Tittle of the essay",
    Emotion:"The intensity of the emotion is high no matter what type is the emotion",
    essay:{
        paragraph1: "paragraph one ",
        paragraph2: "paragraph two ",
        paragraph3: "paragraph three ",
    }
})


const finalChain =  titleChain.pipe(res=>({tittle:res , Emotion:"sadness" , format_instruction:structuredParser.getFormatInstructions()})).pipe(essayChain)

const response  = await finalChain.invoke({topic:"Love is Blind "})
console.log(response.content)