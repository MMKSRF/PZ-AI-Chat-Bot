import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import *  as dotenv from "dotenv";
dotenv.config();

// Replace with your Gemini API key
export const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "your-api-key-here";

// Initialize the Gemini model
const model = new ChatGoogleGenerativeAI({
  apiKey: GEMINI_API_KEY,
  modelName: "gemini-2.0-flash",  // Use the correct model name
  maxTokens: 1000, // this is used to control the length of the response
  temperature: 0.5, // this is used to control the creativity of the model 1 >> for max creative and 0 >> for strict or absolute
  verbose: true, // this is used to control the verbosity of the model

});

const response = await model.invoke("give me the latest news on covid-25");
console.log("Gemini Response:", response);


